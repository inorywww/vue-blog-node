module.exports = {
    mongoURI : "http://49.234.17.206/:27017/db",
    secretOrKey:"secret"
}